# execute limes_characters.xml

```bash

rm -rf .server-storage 
rm limes_accepted_char.nt 
rm limes_reviewme_char.nt 
rm -rf cache

java -jar D:\MSc\Tools\limes.jar limes_characters.xml

```