# network rml mapping
```bash
java -jar D:\MSc\Tools\rmlmapper-4.9.2.jar -m network.rml.ttl -o output_network.ttl -s turtle
```